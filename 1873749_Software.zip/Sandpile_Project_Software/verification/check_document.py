"""Check this report version's pagination, citations, assets and numeric map.

This is a consistency check. Mathematical arguments and visual layout also
require reading the rendered report; new claims need their own evidence check.
"""
from pathlib import Path
import ast
import hashlib
import json
import re
import fitz
import pandas as pd

PACKAGE = Path(__file__).resolve().parents[1]
REPORT = PACKAGE / 'report'
QA = PACKAGE / 'verification'
tex = (REPORT / 'main.tex').read_text()
source = (PACKAGE / 'software/sandpile.py').read_text()
syntax = ast.parse(source)
expected = ['course', 'bak1987', 'dhar1999', 'jarai2018',
            'clauset2009', 'poghosyan2011', 'demenech1998']
citations = [key for group in re.findall(r'\\cite(?:p|t)?(?:\[[^]]*\])?\{([^}]+)\}', tex)
             for key in group.split(',')]
assert citations == expected, citations
assert 'fontsize=10.5pt' in tex and 'margin=2cm' in tex
assert not re.search(r'[\u3400-\u9fff]', tex)
assert not re.search(r'\bnot\b[^.?!;]{0,120}\bbut\b', tex, re.I)
labels = re.findall(r'\\label\{([^}]+)\}', tex)
assert len(labels) == len(set(labels)), 'Duplicate cross-reference labels'
for ref in re.findall(r'\\(?:eq)?ref\{([^}]+)\}', tex):
    assert ref in labels, ref
assets = re.findall(r'\\includegraphics(?:\[[^]]*\])?\{([^}]+)\}', tex)
assert len(assets) == 14
for asset in assets:
    assert (REPORT / asset).is_file(), asset
mapping = pd.read_csv(QA / 'claim_figure_map.csv', dtype={'displayed_value': str})
with fitz.open(REPORT / 'main.pdf') as doc:
    assert len(doc) == 19, len(doc)
    assert all(abs(p.rect.width - 595.276) < .1 and abs(p.rect.height - 841.89) < .1 for p in doc)
    page_text = [p.get_text() for p in doc]
    compact = [''.join(t.split()).replace(',', '').replace('−', '-') for t in page_text]
    for row in mapping.itertuples():
        token = row.displayed_value.replace(',', '').replace('−', '-')
        assert token in compact[row.physical_page - 1], (row.report_location, token)
    first = []
    for text in page_text[:17]:
        for number in re.findall(r'\[(\d+)\]', text):
            value = int(number)
            if value not in first:
                first.append(value)
    assert first == list(range(1, 8)), first
    all_text = '\n'.join(page_text)
    assert '\ufffd' not in all_text, 'Replacement glyph in extracted text'
    bounds = []
    for number, page in enumerate(doc, 1):
        words = page.get_text('words')
        bounds.append({'physical_page': number,
                       'word_count': len(words),
                       'leftmost_text_pt': min(w[0] for w in words),
                       'rightmost_text_pt': max(w[2] for w in words)})
    pd.DataFrame(bounds).to_csv(QA / 'page_checks.csv', index=False)
result = {
    'status': 'PASS',
    'physical_pages': 19,
    'paper': 'A4',
    'main_type_TeX_pt': 10.5,
    'specified_margins_cm': 2,
    'figures': len(assets),
    'tables': len(re.findall(r'\\begin\{table\}', tex)),
    'reference_first_occurrence_order': first,
    'mapped_numerical_entries_found_on_named_pages': len(mapping),
    'source_lines': len(source.splitlines()),
    'source_functions': sum(isinstance(n, ast.FunctionDef) for n in syntax.body),
    'source_classes': sum(isinstance(n, ast.ClassDef) for n in ast.walk(syntax)),
    'pdf_extracted_word_count_including_figures_tables_and_references': len(all_text.split()),
    'report_pdf_sha256': hashlib.sha256((REPORT / 'main.pdf').read_bytes()).hexdigest(),
    'checks': ['All referenced figure assets exist', 'All internal references resolve in source',
               'Citation sequence checked in source and compiled PDF',
               'Mapped rounded numbers found on their recorded PDF pages',
               'No Chinese characters or not-X-but-Y sentence pattern in the report source'],
    'limits': 'Token matching supports the manually reviewed number-to-location map; it is not a proof of all scientific claims. The supplied rendering was also visually reviewed.'
}
(QA / 'document_checks.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))

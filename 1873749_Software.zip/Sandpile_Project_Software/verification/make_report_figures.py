"""Create the final report's single-axis figures from the saved simulation data.
Each plotted summary is also exported as CSV for checking against the report.
"""
from pathlib import Path
import json
import os
os.environ.setdefault('MPLCONFIGDIR', str(Path(__file__).resolve().parent / '.mpl_cache'))
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import spearmanr

PACKAGE = Path(__file__).resolve().parents[1]
ROOT = PACKAGE / 'software'
OUT = PACKAGE / 'report/figures'
QA = PACKAGE / 'verification'
OUT.mkdir(parents=True, exist_ok=True)
stats = pd.read_csv(QA / 'recomputed_groups.csv')
fitting = pd.read_csv(QA / 'recomputed_fits.csv')
records, pooled = {}, {}
for p in sorted((ROOT/'results/data').glob('*.npz')):
    with np.load(p) as z:
        r={k:z[k].copy() for k in z.files}
    m=json.loads(str(r['meta'])); r['m']=m; records[p.stem]=r
    if not p.stem.startswith(('BURN2','ENSEMBLE')):
        group=('Random' if m['random_rule'] else 'BTW')+f" L={m['L']}"
        pooled.setdefault(group,[]).append(r['trace'][m['burn']:])
pooled={k:np.vstack(v) for k,v in pooled.items()}

def stat(group, metric):
    row=stats[(stats.group==group)&(stats.metric==metric)].iloc[0]
    return row['mean'],row['sd']

def finish(name, title, xlabel, ylabel):
    plt.title(title, fontsize=12, pad=10)
    plt.xlabel(xlabel, fontsize=11); plt.ylabel(ylabel, fontsize=11)
    plt.xticks(fontsize=10); plt.yticks(fontsize=10)
    plt.tight_layout(pad=1.0)
    plt.savefig(OUT/f'{name}.pdf',bbox_inches='tight')
    plt.savefig(OUT/f'{name}.png',dpi=220,bbox_inches='tight')
    plt.close()

# This is the largest recorded avalanche in one specified replicate.
r=records['BTW_L32_R0']; step=int(r['peak_step']); i,j=r['positions'][step]
plt.figure(figsize=(6.6,3.8))
plt.imshow(r['peak'],interpolation='nearest',origin='upper')
plt.plot(j,i,marker='x',markersize=9,markeredgewidth=2,linestyle='none',label=f'Addition: row {i}, column {j}')
plt.colorbar(label='Topplings at each site',ticks=range(8))
plt.legend(loc='lower left',fontsize=8)
finish('peak','BTW, L = 32, run 0: s = 2,145; a = 768; d = 29; r = 27.0185','Column (zero-based)','Row (zero-based)')

# Trace shown is a single run; group means are a different figure.
plt.figure(figsize=(7,3.5))
trace=r['trace']; t=np.arange(1,len(trace)+1)
plt.plot(t[::25],trace[::25,4],linewidth=.8,label='BTW, L = 32, run 0')
plt.axvline(r['m']['burn'],linestyle='--',linewidth=1,label='Burn-in ends: 10,240 additions')
plt.ylim(0,2.3); plt.legend(fontsize=9,loc='lower right')
finish('height_trace','Height during loading and the recorded phase','Grain additions from the empty grid','Mean grid height H')
pd.DataFrame({'addition':t[::25],'H':trace[::25,4]}).to_csv(QA/'figure_height_trace.csv',index=False)

names=['BTW L=16','BTW L=32','BTW L=64','Random L=32']
labels=['BTW\nL = 16','BTW\nL = 32','BTW\nL = 64','Random\nL = 32']
plt.figure(figsize=(7,3.2))
for k,g in enumerate(names):
    mean,sd=stat(g,'H')
    plt.errorbar(k,mean,yerr=sd,fmt='o',capsize=5,markersize=5)
    plt.annotate(f'{mean:.4f}',(k,mean),xytext=(0,9),textcoords='offset points',ha='center',fontsize=10)
plt.axhline(2.125,linestyle='--',linewidth=1,label='Infinite BTW benchmark: 2.125')
plt.xticks(range(4),labels); plt.ylim(1.97,2.16); plt.xlim(-.4,3.4)
plt.legend(fontsize=8,loc='upper center')
finish('height_means','Mean height across three runs; error bars show sample SD','Model and grid width','Mean H after burn-in')

means=pd.read_csv(QA/'recomputed_time_ensemble.csv')
plt.figure(figsize=(7,3.1))
for k,row in means.iterrows():
    plt.errorbar(row['mean'],k,xerr=[[row['mean']-row['low']],[row['high']-row['mean']]],fmt='o',capsize=5)
    plt.annotate(f"{row['mean']:.6f}  [{row['low']:.6f}, {row['high']:.6f}]",(row['mean'],k),xytext=(0,14),textcoords='offset points',ha='center',fontsize=9)
plt.yticks([0,1],['Time average\n40 blocks','Ensemble\n20 endpoints']);plt.ylim(-.5,1.6);plt.xlim(2.03,2.08)
finish('time_ensemble','BTW, L = 16: height estimates with approximate 95% intervals','Mean height H','Sampling method')

# Exact empirical positive-value CCDF; no binning and no deletion from raw data.
variables=[('s','Toppling count s'),('a','Avalanche area a'),('d','Boundary loss d'),('r','Propagation radius r')]
for j,(short,label) in enumerate(variables):
    plt.figure(figsize=(7,3.05)); export=[]
    for group in names[:3]:
        vals=pooled[group][:,j]; pos=vals[vals>0]
        values,counts=np.unique(pos,return_counts=True)
        ccdf=np.cumsum(counts[::-1])[::-1]/len(pos)
        plt.loglog(values,ccdf,linewidth=1.1,label=f'{group}; n+ = {len(pos):,}')
        export.extend(dict(group=group,value=v,ccdf=c,n_positive=len(pos)) for v,c in zip(values,ccdf))
    plt.legend(fontsize=8,loc='lower left')
    finish(f'ccdf_btw_{short}',f'BTW: positive-value distribution of {label.lower()}',label,f'P({short} ≥ x | {short} > 0)')
    pd.DataFrame(export).to_csv(QA/f'figure_ccdf_btw_{short}.csv',index=False)

plt.figure(figsize=(6.3,3.8))
ev=pooled['BTW L=32'];ev=ev[ev[:,0]>0,:4];rho=spearmanr(ev).statistic
plt.imshow(rho,vmin=0,vmax=1,interpolation='nearest')
plt.colorbar(label='Spearman correlation')
plt.xticks(range(4),['s','a','d','r']);plt.yticks(range(4),['s','a','d','r'])
for j in range(4):
    for k in range(4):
        plt.text(k,j,f'{rho[j,k]:.4f}',ha='center',va='center',fontsize=10,
                 bbox=dict(boxstyle='round,pad=0.17',alpha=.25))
finish('correlation','BTW, L = 32: all 25,130 nonzero avalanches','Avalanche measure','Avalanche measure')

plt.figure(figsize=(7,3.5))
for g in ('BTW L=32','Random L=32'):
    f=fitting[fitting.group==g]
    plt.semilogx(f.xmin,f.alpha,marker='o',linewidth=1,label=g)
    for idx in [f.index[0],f.index[-1]]:
        row=f.loc[idx]
        initial = idx == f.index[0]
        dy = (-13 if g.startswith('BTW') else 12) if initial else (7 if g.startswith('BTW') else -15)
        plt.annotate(f'{row.alpha:.4f}',(row.xmin,row.alpha),xytext=(5,dy),
                     textcoords='offset points',fontsize=9,
                     arrowprops={'arrowstyle':'-','linewidth':.5})
plt.xticks([5,10,20,50,100,200],['5','10','20','50','100','200']);plt.xlim(4,330);plt.ylim(1.30,2.60)
plt.legend(fontsize=9)
finish('fit_threshold','Discrete power-law estimates depend on the fitting threshold','Lower fitting threshold s_min','Estimated exponent alpha')

plt.figure(figsize=(7,3.05));export=[]
for g in ('BTW L=32','Random L=32'):
    pos=pooled[g][:,0];pos=pos[pos>0]
    values,counts=np.unique(pos,return_counts=True);ccdf=np.cumsum(counts[::-1])[::-1]/len(pos)
    plt.loglog(values,ccdf,label=f'{g}; n+ = {len(pos):,}',linewidth=1.1)
    export.extend(dict(group=g,s=v,ccdf=c) for v,c in zip(values,ccdf))
plt.legend(fontsize=9,loc='lower left')
finish('random_ccdf','Effect of random redistribution at L = 32','Toppling count s','P(s ≥ x | s > 0)')
pd.DataFrame(export).to_csv(QA/'figure_random_ccdf.csv',index=False)

metrics=[('mean_s_event','Mean s | s > 0'),('mean_a_event','Mean a | s > 0'),('mean_r_event','Mean r | s > 0'),('s_q99','99th percentile of s | s > 0'),('mean_s_all','Mean s, all additions')]
plt.figure(figsize=(7,3.5));effects=[]
for k,(metric,label) in enumerate(metrics):
    old=stat('BTW L=32',metric)[0];new=stat('Random L=32',metric)[0];effect=100*(new/old-1)
    plt.plot([0,effect],[k,k],marker='o',markevery=[1],linewidth=2)
    plt.annotate(f'{effect:+.2f}%',(effect,k),xytext=(6 if effect>=0 else -6,0),textcoords='offset points',va='center',ha='left' if effect>=0 else 'right',fontsize=9)
    effects.append(dict(metric=metric,BTW=old,Random=new,relative_change_percent=effect))
plt.yticks(range(len(metrics)),[z[1] for z in metrics]);plt.axvline(0,linestyle='--',linewidth=.7)
plt.xlim(-62,85);plt.ylim(4.5,-.6)
finish('rule_effects','Relative changes in run-averaged summaries at L = 32','100 × (random / BTW − 1), percent','Summary statistic')
pd.DataFrame(effects).to_csv(QA/'figure_rule_effects.csv',index=False)

plt.figure(figsize=(7,3.4))
for rule in ('BTW','Random'):
    ys=[];es=[]
    for g in (f'{rule} L=32',f'BURN2 {rule} L=32'):
        y,e=stat(g,'s_q99');ys.append(y);es.append(e)
    plt.errorbar([10240,20480],ys,yerr=es,fmt='o-',capsize=5,label=rule)
    for x,y in zip([10240,20480],ys):
        plt.annotate(f'{y:,.2f}',(x,y),xytext=(0,11),textcoords='offset points',ha='center',fontsize=9)
plt.xticks([10240,20480],['10,240','20,480']);plt.xlim(8500,22200);plt.ylim(760,1660);plt.legend(fontsize=9)
finish('burn_q99','L = 32: sensitivity of the 99th percentile to burn-in','Burn-in additions','Mean run-level 99th percentile\nof s, conditional on s > 0')
print("Updated 13 data plots; the algorithm flowchart is supplied separately.")

# Verification records

The report audit and numerical maps concern the existing final report in `../report/`. The final report, source figures and scientific records have been retained. `audit_report.py` and `check_document.py` were rerun when assembling the coursework stages. Their outputs are `numerical_audit.json`, the `recomputed_*.csv` tables and `document_checks.json`.

Some records describe earlier checks: `reference_audit.json`, `resume_verification.json`, `clean_build_check.json`, `package_sha256.json` and the workflow notes belong to the earlier final-report preparation. In particular, `package_sha256.json` is the manifest of that earlier package layout; use the new top-level coursework manifest for the newly assembled delivery.

The earlier draft had different page numbers and a shorter final discussion. Its checks were stored under `07_Continuity_and_Checks` in the earlier full coursework archive; that historical draft directory is outside this final software ZIP. The current final report checks and numerical map are in this `verification/` directory.

## Current submission (18 October 2026)

The editable final report is report/main.tex. The current delivered-file manifest is ../MANIFEST.sha256. The current validation summary is current_submission_checks.json. Earlier package manifests and workflow notes describe previous preparation and are retained as historical records.

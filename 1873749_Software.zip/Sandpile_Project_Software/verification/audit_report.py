"""Recalculate the report's numerical evidence from the unchanged saved trajectories."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import spearmanr, t
from scipy.sparse import diags, eye, kron
from scipy.sparse.linalg import spsolve

PACKAGE = Path(__file__).resolve().parents[1]
ROOT = PACKAGE / 'software'
OUT = PACKAGE / 'verification'
OUT.mkdir(parents=True, exist_ok=True)
spec = importlib.util.spec_from_file_location('model', ROOT / 'sandpile.py')
model = importlib.util.module_from_spec(spec)
spec.loader.exec_module(model)
records, rows, group_arrays, hashes = {}, [], {}, {}
steps = 0
for path in sorted((ROOT / 'results/data').glob('*.npz')):
    with np.load(path) as z:
        r = {k: z[k].copy() for k in z.files}
    m = json.loads(str(r['meta']))
    r['metadata'] = m
    x = r['trace'][m['burn']:]
    mass = np.rint(r['trace'][:, 4] * m['L']**2).astype(np.int64)
    loss = r['trace'][:, 2].astype(np.int64)
    assert np.array_equal(np.diff(np.r_[0, mass]), 1-loss), path.name
    assert (r['trace'][:, 1] <= r['trace'][:, 0]).all()
    assert (r['grid'] >= 0).all() and (r['grid'] < 4).all()
    assert int(r['grid'].sum()) == mass[-1]
    steps += len(r['trace'])
    hashes[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
    records[path.stem] = r
    if path.stem.startswith('ENSEMBLE'):
        continue
    ev = x[x[:, 0] > 0]
    d = dict(H=float(x[:,4].mean()), p_avalanche=float((x[:,0]>0).mean()),
             p_loss=float((x[:,2]>0).mean()), mean_s_all=float(x[:,0].mean()),
             mean_s_event=float(ev[:,0].mean()), mean_a_event=float(ev[:,1].mean()),
             mean_r_event=float(ev[:,3].mean()), mean_d_all=float(x[:,2].mean()),
             s_q95=float(np.quantile(ev[:,0], .95)), s_q99=float(np.quantile(ev[:,0], .99)),
             n_event=len(ev))
    group = ('Random' if m['random_rule'] else 'BTW') + f" L={m['L']}"
    if path.stem.startswith('BURN2'):
        group = 'BURN2 ' + group
    rows.append(dict(run=path.stem,group=group,**m,**d))
    group_arrays.setdefault(group, []).append(x)
run = pd.DataFrame(rows)
run.to_csv(OUT/'recomputed_runs.csv',index=False)
stats = []
for group, sub in run.groupby('group', sort=False):
    for metric in d:
        stats.append(dict(group=group,metric=metric,mean=float(sub[metric].mean()),
                          sd=float(sub[metric].std(ddof=1))))
group_stats = pd.DataFrame(stats)
group_stats.to_csv(OUT/'recomputed_groups.csv',index=False)
original=pd.read_csv(ROOT/'results/group_summary.csv')
merged=original.merge(group_stats,on=['group','metric'],suffixes=('_reference','_new'))
# Retain all reference precision; numeric differences are allowed only at roundoff level.
for metric in ('mean','sd'):
    assert np.allclose(merged[metric+'_reference'],merged[metric+'_new'],rtol=1e-12,atol=1e-12)

fits, corr, zero = [], [], []
for group, arrays in group_arrays.items():
    if group.startswith('BURN2'):
        continue
    x=np.vstack(arrays)
    for j,var in enumerate(('s','a','d','r')):
        zero.append(dict(group=group,variable=var,p_zero=float((x[:,j]==0).mean()),n_positive=int((x[:,j]>0).sum())))
    ev=x[x[:,0]>0,:4]
    rho=spearmanr(ev).statistic
    for j in range(4):
        for k in range(j+1,4):
            corr.append(dict(group=group,pair=('s','a','d','r')[j]+('s','a','d','r')[k],rho=float(rho[j,k])))
    for xmin in (5,10,20,50,100,200):
        fits.append(dict(group=group,**model.fit_tail(x[:,0],xmin)))
pd.DataFrame(corr).to_csv(OUT/'recomputed_correlations.csv',index=False)
pd.DataFrame(zero).to_csv(OUT/'recomputed_zeros.csv',index=False)
pd.DataFrame(fits).to_csv(OUT/'recomputed_fits.csv',index=False)
ref_fit=pd.read_csv(ROOT/'results/exploratory_powerlaw.csv')
ff=ref_fit.merge(pd.DataFrame(fits),on=['group','xmin'],suffixes=('_ref','_new'))
# Bounded optimisation and special functions differ by a few 1e-11 between
# platforms, even with the same NumPy/SciPy versions. This tolerance remains
# well below the precision reported in the tables and text.
assert np.allclose(ff.alpha_ref,ff.alpha_new,rtol=1e-9,atol=1e-9)

tr=records['BTW_L16_R0']; heights=tr['trace'][tr['metadata']['burn']:,4]
batches=heights.reshape(40,500).mean(axis=1)
ensemble=np.array([r['trace'][-1,4] for name,r in records.items() if name.startswith('ENSEMBLE')])
means=[]
for label,y in [('Time average',batches),('Independent ensemble',ensemble)]:
    se=y.std(ddof=1)/np.sqrt(len(y)); hw=t.ppf(.975,len(y)-1)*se
    means.append(dict(method=label,n=len(y),mean=y.mean(),se=se,low=y.mean()-hw,high=y.mean()+hw))
pd.DataFrame(means).to_csv(OUT/'recomputed_time_ensemble.csv',index=False)

theory=[]
for L in (16,32,64):
    T=diags([-np.ones(L-1),2*np.ones(L),-np.ones(L-1)],[-1,0,1])
    A=kron(eye(L),T)+kron(T,eye(L)); b=np.ones(L*L)/(L*L)
    v=spsolve(A.tocsr(),b)
    theory.append(dict(L=L,mean_s=float(v.sum()),max_residual=float(np.max(abs(A@v-b)))))
pd.DataFrame(theory).to_csv(OUT/'recomputed_theory.csv',index=False)

peak=records['BTW_L32_R0']; p=int(peak['peak_step'])
site=peak['positions'][p]; coordinates=np.argwhere(peak['peak']>0)
metrics=peak['trace'][p,:4]
assert metrics[0]==peak['peak'].sum() and metrics[1]==len(coordinates)
assert np.isclose(metrics[3],np.sqrt(((coordinates-site)**2).sum(axis=1).max()))

pairs=[]
for rep in range(3):
    for left,right in [(f'BTW_L32_R{rep}',f'RANDOM_L32_R{rep}'),
                       (f'BTW_L32_R{rep}',f'BURN2_BTW_L32_R{rep}'),
                       (f'RANDOM_L32_R{rep}',f'BURN2_RANDOM_L32_R{rep}')]:
        l,r=records[left],records[right]
        assert np.array_equal(l['positions'][l['metadata']['burn']:],r['positions'][r['metadata']['burn']:])
        pairs.append([left,right])
burning_checked = []
for name, record in records.items():
    if record['metadata']['random_rule']:
        continue
    h = record['grid'].copy()
    deficit = np.zeros_like(h)
    deficit[0, :] += 1
    deficit[-1, :] += 1
    deficit[:, 0] += 1
    deficit[:, -1] += 1
    candidate = h + deficit
    topplings, boundary_loss = model.relax(candidate)
    assert np.array_equal(candidate, h) and (topplings == 1).all(), name
    burning_checked.append(name)
source=(ROOT/'sandpile.py').read_text()
syntax=ast.parse(source)
checks=model.check_model()
result=dict(status='PASS',npz_files=len(records),saved_steps=steps,
            main_recorded_steps=sum(len(x) for g,xs in group_arrays.items() if not g.startswith('BURN2') for x in xs),
            main_avalanches=int(run[~run.group.str.startswith('BURN2')].n_event.sum()),
            mass_balance_max_residual=0,matched_paired_drives=len(pairs),
            recurrent_final_configurations_checked=len(burning_checked),
            model_tests_rerun=checks,source_lines=len(source.splitlines()),
            functions=sum(isinstance(n,ast.FunctionDef) for n in syntax.body),
            classes=sum(isinstance(n,ast.ClassDef) for n in ast.walk(syntax)),
            source_sha256=hashlib.sha256((ROOT/'sandpile.py').read_bytes()).hexdigest(),
            reproduced_summary_rows=len(merged),reproduced_fits=len(ff),
            peak=dict(run='BTW_L32_R0',full_index=p,postburn_addition=p-peak['metadata']['burn']+1,
                      addition_site_zero_based=site.tolist(),s=int(metrics[0]),a=int(metrics[1]),d=int(metrics[2]),r=float(metrics[3]),max_site_topplings=int(peak['peak'].max())),
            notes='Read-only audit of saved data; full simulation was not rerun for this report. Model tests were rerun.')
(OUT/'numerical_audit.json').write_text(json.dumps(result,indent=2))
(OUT/'data_sha256.json').write_text(json.dumps(hashes,indent=2))
print(json.dumps(result,indent=2))

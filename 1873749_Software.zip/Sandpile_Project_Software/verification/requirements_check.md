# Coursework requirements checked

## Sources used

The original sandpile questions are in the supplied `COMP90072 - Complex - project.pdf` (17 August 2020). The uploaded archive also contains LMS screenshots and an older exported final-report guide, `final_report(2).pdf`. The report follows the sandpile questions and uses that supplied guide for the concrete layout and content checklist.

The exported guide contains historical submission information. Those dates and email instructions have not been adopted as current requirements, and the current LMS was not accessed. This check therefore establishes consistency with the materials supplied for this task.

| Supplied requirement | Location or check |
|---|---|
| LaTeX report | `report/main.tex`, compiled PDF and bibliography provided |
| A4, 10.5-point main type, margins at most 2 cm | Class option `fontsize=10.5pt`, A4 paper and `geometry` margin=2cm |
| 15–20 pages in total | 19 physical PDF pages |
| Dedicated title page | Physical page 1; Zhang Wenbo, 1873749, 18 October 2026 |
| Introduction and goals | Chapter 1 |
| Computational method with simple flowchart | Chapter 3, Figure 1 |
| Core results with interpretation | Chapter 4 |
| An extension and its results | Chapter 5, independent random directions for four outgoing grains |
| Discussion | Chapter 6 |
| At least five scholarly references | Six scholarly publications plus the course handout |
| All sandpile questions addressed | Table 11 maps Questions 1–12 and extension option 2 to report sections |
| Program and run instructions | `software/sandpile.py`, requirements and README files |
| Beginner-accessible function structure | Main program: 300 physical lines, nine functions, no classes |
| Sequential citations requested by the student | New references first occur as [1], [2], [3], [4], [5], [6], [7] |

The extra reporting and audit scripts are provided separately from the 300-line teaching program. The project makes no claim of a newly discovered universality class or a precisely identified asymptotic power-law exponent.
# Historical preparation notes

This document records requirements and screenshots supplied during an earlier
preparation stage. References below to LMS screenshots, `final_report(2).pdf`,
or the earlier full coursework archive are historical inputs, not files included
in this software ZIP or evidence of a current LMS submission. For the current
delivery, Project software requires a ZIP/tarball with all code, run instructions
and dependencies; Final report requires a PDF. See the root README and
`current_submission_checks.json` for the current deliverables and verification.


# Writing workflow and provenance

The public PaperSpine and Nature-writing playbooks were consulted as writing guidance. They were read from their repositories; this delivery does not claim that locally installed plugins bearing those names were invoked.

PaperSpine: https://github.com/WUBING2023/PaperSpine
Entry point consulted: `dist/codex/skills/paper-spine/SKILL.md`, with its build, results and citation guidance.

Nature-writing: https://github.com/Yuan1z0825/nature-skills
Entry point consulted: `skills/nature-writing/SKILL.md`, with workflow, research/manuscript, language and section guidance.

The report uses evidence-led paragraphs, links each central result to its plotted or tabulated quantity, states sampling conditions, separates observations from mechanistic interpretation, and keeps limitations beside the relevant findings. The supplied coursework structure and page range take priority over journal-style novelty, journal branding or a large reference list.

All six scholarly reference records were checked against their primary publication or author-hosted records. The course handout supplies the remaining entry. No detector score, guarantee of human authorship, external peer review or publication acceptance is claimed. AI assistance is acknowledged in the report.

## Resumed delivery

The saved report and its source package were recovered without changing the simulation records. The numerical audit, model cross-checks and document consistency checks were run again, and the report was recompiled. All 19 rendered pages were reviewed; the rebuilt pages match the saved version in both extracted text and raster content.

For the resumed review, the current PaperSpine entry point at `src/skill/SKILL.md` and its resume, result-validation and citation guidance were consulted. The Nature-writing main-text and discussion guidance, manuscript fragment, English-language fragment and evidence-first stance informed the final read-through. These are public reference files, not installed or independently executing plugins. The delivered editing source is LaTeX, matching the supplied coursework requirements. No course submission or independent external review was performed.

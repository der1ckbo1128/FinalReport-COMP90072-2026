"""Sandpile project: test, demo, full simulation, and analysis from saved data."""
import argparse
import csv
import json
import platform
import time
from collections import deque
from pathlib import Path
import numpy as np
import scipy
from scipy.optimize import minimize_scalar
from scipy.special import zeta
from scipy.stats import spearmanr, t
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
DIRS = ((-1, 0), (1, 0), (0, -1), (0, 1))
LABELS = ("Topples s", "Area a", "Loss d", "Radius r")

def relax(h, start=None, rng=None, fifo=False):
    """Q7, Q9-Q12: fully relax the grid and count topplings and boundary loss."""
    L = len(h)
    work = deque([start] if start is not None else map(tuple, np.argwhere(h >= 4)))
    u, loss = np.zeros_like(h), 0
    while work:
        i, j = work.popleft() if fifo else work.pop()
        if h[i, j] < 4:
            continue
        h[i, j] -= 4
        u[i, j] += 1  # Count every toppling in s; each visited site contributes once to area a.
        directions = range(4) if rng is None else rng.integers(4, size=4)
        for k in directions:
            di, dj = DIRS[k]
            x, y = i + di, j + dj
            if 0 <= x < L and 0 <= y < L:
                h[x, y] += 1
                if h[x, y] == 4:
                    work.append((x, y))
            else:
                loss += 1  # A grain sent outside the grid is lost; keep the original direction.
        if h[i, j] >= 4:
            work.append((i, j))
    return u, loss

def simulate(L, burn, n, seed, random_rule=False):
    """Q4-Q8: use separate random streams for burn-in, sampling, and redistribution."""
    if L < 1 or burn < 0 or n < 1:
        raise ValueError("L and n must be positive, and burn must be non-negative")
    positions = np.vstack([np.random.default_rng([L, seed, k]).integers(L, size=(m, 2))
                           for k, m in enumerate((burn, n))])
    rng = np.random.default_rng([L, seed, 2]) if random_rule else None
    h = np.zeros((L, L), dtype=np.int64)
    trace = np.empty((burn + n, 5))
    peak, peak_step, largest = h.copy(), -1, -1
    begin = time.perf_counter()
    for step, point in enumerate(positions):
        site = tuple(map(int, point))
        before = int(h.sum())
        h[site] += 1
        u, loss = relax(h, site, rng)
        s, a = int(u.sum()), int(np.count_nonzero(u))
        radius = np.sqrt(np.max(np.sum((np.argwhere(u > 0) - point) ** 2, axis=1))) if a else 0.
        mass = int(h.sum())
        if mass != before + 1 - loss or h.min() < 0 or h.max() >= 4 or a > s:
            raise RuntimeError(f"Mass balance or stability check failed at step={step}")
        trace[step] = (s, a, loss, radius, mass / L**2)
        if step >= burn and s > largest:
            peak, peak_step, largest = u.copy(), step, s
    meta = dict(L=L, burn=burn, n=n, seed=seed, random_rule=random_rule,
                seconds=time.perf_counter() - begin)
    return dict(trace=trace, positions=positions, grid=h, peak=peak,
                peak_step=peak_step, meta=json.dumps(meta))

def check_model():
    """Q9-Q12: check small cases, all 2-by-2 states, and a separate array algorithm."""
    for site, expected_loss in [((1, 1), 0), ((0, 1), 1), ((0, 0), 2)]:
        h = np.zeros((3, 3), dtype=int)
        h[site] = 4
        u, d = relax(h)
        assert u.sum() == 1 and d == expected_loss and h.sum() == 4 - d
    h = np.array([[1, 3, 3], [2, 4, 2], [2, 1, 1]])
    u, d = relax(h)
    assert np.array_equal(h, [[2, 1, 1], [3, 2, 0], [2, 2, 2]]) and d == 4 and u.sum() == 4
    rng = np.random.default_rng(731)
    initial = [rng.integers(0, 12, (8, 8)) for _ in range(100)]
    for code in range(256):
        h = np.array([(code // 4**k) % 4 for k in range(4)]).reshape(2, 2)
        for k in range(4):
            g = h.copy()
            g.flat[k] += 1
            initial.append(g)
    for h in initial:
        a, b, c = h.copy(), h.copy(), h.copy()
        u, d = relax(a)
        v, e = relax(b, fifo=True)
        w = np.zeros_like(c)
        while np.any(c >= 4):
            q = c // 4  # Use synchronous array updates to check the queue implementation.
            w += q
            c -= 4 * q
            c[1:] += q[:-1]
            c[:-1] += q[1:]
            c[:, 1:] += q[:, :-1]
            c[:, :-1] += q[:, 1:]
        assert np.array_equal(a, b) and np.array_equal(a, c)
        assert np.array_equal(u, v) and np.array_equal(u, w) and d == e == h.sum() - a.sum()
    tiny = simulate(1, 0, 8, 5)
    assert np.array_equal(tiny["trace"][:, 4], [1, 2, 3, 0, 1, 2, 3, 0])
    for seed in range(20):
        simulate(4, 100, 100, seed, True)
    return dict(status="PASS", local_cases=4, cross_checks=len(initial),
                L1_period_test=True, stochastic_checked_steps=4000)

def write_csv(path, rows):
    with Path(path).open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

def describe(x):
    z = x[x[:, 0] > 0]
    return dict(H=x[:, 4].mean(), p_avalanche=np.mean(x[:, 0] > 0),
                p_loss=np.mean(x[:, 2] > 0), mean_s_all=x[:, 0].mean(),
                mean_s_event=z[:, 0].mean(), mean_a_event=z[:, 1].mean(),
                mean_d_all=x[:, 2].mean(), mean_r_event=z[:, 3].mean(),
                s_q95=np.quantile(z[:, 0], .95), s_q99=np.quantile(z[:, 0], .99),
                max_s=z[:, 0].max(), n_event=len(z))

def fit_tail(x, xmin):
    """Q7: exploratory discrete power-law MLE; record KS distance as a diagnostic."""
    y = x[x >= xmin]
    if len(y) < 100:
        return dict(xmin=xmin, n_tail=len(y), alpha=np.nan, KS=np.nan)
    objective = lambda alpha: len(y) * np.log(zeta(alpha, xmin)) + alpha * np.log(y).sum()
    fit = minimize_scalar(objective, bounds=(1.001, 20), method="bounded")
    if not fit.success:
        raise RuntimeError("Power-law parameter optimisation did not converge")
    values, counts = np.unique(y, return_counts=True)
    empirical = np.cumsum(counts) / len(y)
    model = 1 - zeta(fit.x, values + 1) / zeta(fit.x, xmin)
    left = 1 - zeta(fit.x, values) / zeta(fit.x, xmin)
    D = max(np.max(abs(empirical - model)), np.max(abs(empirical - counts / len(y) - left)))
    return dict(xmin=xmin, n_tail=len(y), alpha=fit.x, KS=D)

def finish(folder, name, xlabel, ylabel, title):
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.title(title)
    plt.tight_layout()
    plt.savefig(folder / (name + ".png"), dpi=170)
    plt.close()

def analyse(out):
    """Rebuild summary tables, exact frequencies, and figures from saved runs."""
    figures = out / "figures"
    figures.mkdir(exist_ok=True)
    groups, rows, halves, fits, ensemble, acfs = {}, [], [], [], [], []
    plt.figure(figsize=(8, 4.8))
    for file in sorted((out / "data").glob("*.npz")):
        record = np.load(file)
        m = json.loads(str(record["meta"]))
        x = record["trace"][m["burn"]:]
        name = file.stem
        if name.startswith("ENSEMBLE"):
            ensemble.append(float(x[-1, 4]))
            continue
        row = dict(run=name, **m, **describe(x))
        rows.append(row)
        chunks = [("warmup", np.array_split(record["trace"][m["burn"]//2:m["burn"]], 3)),
                  ("sample", np.array_split(x, 10))]
        for phase, blocks in chunks:
            for k, block in enumerate(blocks):
                halves.append(dict(run=name, phase=phase, block=k + 1, **describe(block)))
        if name.startswith("BURN2"):
            continue
        key = ("Random" if m["random_rule"] else "BTW") + f" L={m['L']}"
        groups.setdefault(key, []).append(x)
        np.savetxt(out / "data" / (name + "_postburn.csv.gz"), np.c_[record["positions"][m["burn"]:], x],
                   delimiter=",", header="drop_i,drop_j,s,a,d,r,H", comments="", fmt="%.12g")
        if m["seed"] == 1000:
            trace = record["trace"]
            plt.plot(np.arange(len(trace))[::25] / m["L"]**2, trace[::25, 4], label=key)
        series = x[:, 4] - x[:, 4].mean()
        ft = np.fft.rfft(series, n=2**int(np.ceil(np.log2(2 * len(series)))))
        acf = np.fft.irfft(ft * ft.conj())[:min(1001, len(series))]
        acfs.extend(dict(run=name, lag=i, H_acf=v / acf[0]) for i, v in enumerate(acf))
    plt.legend()
    finish(figures, "01_height", "Added grains / L^2", "Mean height H", "First replicate; includes burn-in")
    for name, data in [("summary", rows), ("blocks", halves), ("height_acf", acfs)]:
        write_csv(out / (name + ".csv"), data)
    aggregate = []
    for key, series in groups.items():
        metrics = [describe(x) for x in series]
        for metric in metrics[0]:
            values = np.array([r[metric] for r in metrics])
            aggregate.append(dict(group=key, metric=metric, mean=values.mean(),
                                  sd=values.std(ddof=1) if len(values) > 1 else np.nan, repeats=len(values)))
        x = np.concatenate(series)
        z = x[x[:, 0] > 0]
        corr = spearmanr(z[:, :4]).statistic
        np.savetxt(out / (key.replace(" ", "_") + "_spearman.csv"), corr, delimiter=",", header="s,a,d,r")
        plt.figure(figsize=(5, 4.5))
        plt.imshow(corr, vmin=-1, vmax=1)
        plt.colorbar(label="Spearman rho; s > 0")
        plt.xticks(range(4), ["s", "a", "d", "r"])
        plt.yticks(range(4), ["s", "a", "d", "r"])
        for i in range(4):
            for j in range(4):
                plt.text(j, i, f"{corr[i,j]:.3f}", ha="center", va="center")
        finish(figures, "correlation_" + key, "", "", f"{key}; {len(z)} nonzero avalanches")
        for xmin in (5, 10, 20, 50, 100, 200):
            fits.append(dict(group=key, **fit_tail(z[:, 0], xmin)))
        for j, label in enumerate(LABELS):
            values, counts = np.unique(x[:, j], return_counts=True)
            np.savetxt(out / f"frequency_{key}_{j}.csv", np.c_[values, counts, counts / len(x)],
                       delimiter=",", header="value,count,p_all_steps", comments="", fmt="%.12g")
    write_csv(out / "group_summary.csv", aggregate)
    write_csv(out / "exploratory_powerlaw.csv", fits)
    for j, label in enumerate(LABELS):
        for kind in ("ccdf_sizes", "ccdf_rules", "density_rules"):
            plt.figure(figsize=(7, 4.8))
            for key, series in groups.items():
                if ("sizes" in kind and not key.startswith("BTW")) or ("rules" in kind and "L=32" not in key):
                    continue
                x = np.concatenate(series)[:, j]
                positive = x[x > 0]  # Plot this variable conditional on X > 0; retain zeros in the raw data.
                if "density" in kind:
                    edges = np.geomspace(1, positive.max() + 1, 35)
                    edges = np.unique(np.round(edges)) if j < 3 else edges
                    hist, edges = np.histogram(positive, bins=edges, density=True)
                    plt.loglog(np.sqrt(edges[:-1] * edges[1:]), np.where(hist > 0, hist, np.nan), ".-", label=f"{key}; n+={len(positive)}")
                else:
                    values, counts = np.unique(positive, return_counts=True)
                    plt.loglog(values, np.cumsum(counts[::-1])[::-1] / len(positive), label=f"{key}; n+={len(positive)}")
            plt.legend(fontsize=8)
            finish(figures, f"{kind}_{j}", label, "Conditional density" if "density" in kind else "P(X >= x | X > 0)",
                   "Post-burn-in; positive values only")
    for key, series in groups.items():
        x = np.concatenate(series)
        z = x[x[:, 0] > 0]
        sample = z[np.random.default_rng(87).choice(len(z), min(2500, len(z)), replace=False)]
        for j in (1, 2, 3):
            if "L=32" in key:
                plt.figure(figsize=(6, 4.5))
                plt.scatter(np.log10(sample[:, 0]), np.log10(sample[:, j] + 1), s=4, alpha=.25)
                finish(figures, f"scatter_{key}_{j}", "log10(s)", f"log10({LABELS[j]} + 1)", f"{key}; {len(sample)} sampled events")
    if ensemble and "BTW L=16" in groups:
        x = groups["BTW L=16"][0][:, 4]
        blocks = np.array([v.mean() for v in np.array_split(x, 40)])
        comparison = []
        for name, values in [("time_40_batches", blocks), ("ensemble_20_endpoints", np.array(ensemble))]:
            se = values.std(ddof=1) / np.sqrt(len(values))
            comparison.append(dict(method=name, n=len(values), mean=values.mean(), se=se,
                                   halfwidth95=t.ppf(.975, len(values) - 1) * se))
        write_csv(out / "time_vs_ensemble.csv", comparison)
        np.savetxt(out / "ensemble_heights.csv", ensemble, header="H", comments="")
    sample_file = out / "data" / "BTW_L32_R0.npz"
    if sample_file.exists():
        record = np.load(sample_file)
        for field in ("grid", "peak"):
            plt.figure(figsize=(5.5, 4.5))
            plt.imshow(record[field], interpolation="nearest")
            plt.colorbar(label="Height" if field == "grid" else "Topples per site")
            finish(figures, field, "Column", "Row", "BTW L=32; final grid" if field == "grid" else "Largest recorded event, replicate 0")

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["test", "demo", "full", "analyse"])
    parser.add_argument("--out", type=Path, default=Path("results"))
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "data").mkdir(exist_ok=True)
    if args.mode == "analyse":
        analyse(args.out)
        return
    checks = check_model()
    (args.out / "validation.json").write_text(json.dumps(checks, indent=2), encoding="utf-8")
    print(checks, flush=True)
    if args.mode == "test":
        return
    if any((args.out / "data").glob("*.npz")):
        raise FileExistsError("The output folder already contains runs; choose a new --out or use analyse")
    jobs = []
    for random_rule, L in [(False, 16), (False, 32), (False, 64), (True, 32)]:
        for r in range(3 if args.mode == "full" else 1):
            name = ("RANDOM" if random_rule else "BTW") + f"_L{L}_R{r}"
            jobs.append((name, L, max(5000, 10 * L**2), 20000 if args.mode == "full" else 1000, 1000 + r, random_rule))
    if args.mode == "full":
        jobs += [(f"BURN2_{rule}_L32_R{r}", 32, 20480, 20000, 1000 + r, rule == "RANDOM")
                 for rule in ("BTW", "RANDOM") for r in range(3)]
        jobs += [(f"ENSEMBLE_L16_R{r:02}", 16, 5000, 1, 2000 + r, False) for r in range(20)]
    for name, L, burn, n, seed, random_rule in jobs:
        result = simulate(L, burn, n, seed, random_rule)
        np.savez_compressed(args.out / "data" / (name + ".npz"), **result)
        print(name, result["meta"], flush=True)
    environment = dict(python=platform.python_version(), numpy=np.__version__, scipy=scipy.__version__, matplotlib=matplotlib.__version__)
    (args.out / "environment.json").write_text(json.dumps(environment, indent=2), encoding="utf-8")
    analyse(args.out)
if __name__ == "__main__":
    main()

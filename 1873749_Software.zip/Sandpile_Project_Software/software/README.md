# Core simulation and data definitions

Run the commands in the parent `README.md` from the software archive root. This folder contains the unchanged 300-line function-based program and the saved reference data.

## Model

The square grid has threshold 4 at every site and open boundaries. Each uniformly chosen addition is followed by complete relaxation. In the deterministic rule, each direction receives one grain per toppling. In the random rule, each outgoing grain selects a direction independently; a draw outside the grid causes loss.

## NPZ fields

| Key | Content |
|---|---|
| `trace` | Array with `(burn + n, 5)` rows/columns; columns are s, a, d, r, H |
| `positions` | Addition positions for every driving step, including burn-in |
| `grid` | Final stable height array |
| `peak` | Site-level toppling counts for the largest-s event in the recorded phase |
| `peak_step` | Zero-based index of that event in the full trace |
| `meta` | JSON string containing L, burn, n, seed, random_rule and seconds |

Load NPZ data with `np.load`; no pickle objects are needed. The recorded phase begins at `trace[burn:]`. Each compressed `*_postburn.csv.gz` is a readable copy of one main run after burn-in. Row and column indices start at zero.

## Quantities

s is total topplings; a is the number of distinct toppled sites; d is boundary loss; r is maximum Euclidean distance from the addition site to a toppled site; H is total stable mass divided by L². Lattice spacing is one. An avalanche has s > 0. Radius can still be zero during an avalanche confined to one site.

Probabilities, mean_s_all and mean_d_all use all recorded additions. mean_s_event, mean_a_event, mean_r_event, s_q95 and s_q99 condition on s > 0. Spearman correlations use that event sample while retaining d = 0 and r = 0. Each positive-value CCDF conditions on X > 0 for the displayed variable, with the zero frequency reported separately.

`group_summary.csv` reports the mean and sample SD of three run-level estimates. A run-averaged percentile can differ from the percentile of pooled events. A grouped run maximum likewise averages the separate maxima.

## Reproduction

The fixed main seeds are 1000–1002; independent ensemble seeds are 2000–2019. Paired comparisons use identical recorded driving positions, with distinct streams for burn-in positions and random outgoing directions. Meta fields record each run's settings.

`analyse` rebuilds core summaries, exact frequencies, correlations, time–ensemble comparisons, the exploratory fits and the original 25 figures. The parent `verification` scripts provide report-specific audits and figure assets. The full earlier analysis is in `../documentation/analysis_notes.md`. Original audit and environment records describe the reference execution.

The course handout and skeleton were the source references. AI assistance was used in implementation and analysis, as disclosed in the report. See the parent README for installation, permitted-use and submission reminders.

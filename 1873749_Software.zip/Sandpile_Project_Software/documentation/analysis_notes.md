# Sandpile project: calculations and answers to Questions 1–12

COMP90072 — The Art of Scientific Computing  
English analysis notes | 16 September 2026

These notes bring together the simulation results, checks, and answers to the sandpile questions. I have kept the calculations here so that they can be used when the report is written separately. The earlier project plan is in the `planning` folder.

I used the questions in *COMP90072 - Complex - project.pdf* and chose the extension in which each outgoing grain picks a random direction. In the handout's printed page numbering, Question 1 is on page 2, Questions 2–4 on page 5, Questions 5–8 on page 6, Questions 9–11 on page 8, and Question 12 and the chosen extension on page 9. [C1]

The numerical values below come from the saved runs in this package. The English revision keeps those data unchanged. Where a calculation gives a theoretical result, I state the assumptions used. I also keep the original height guess of 1.5, so it is clear how that guess compares with the simulation.

## A. Model, experiments, and checks

### A1. Runs included in the analysis

| Experiment | Grid width L | Burn-in steps per run | Recorded steps after burn-in | Runs |
|---|---:|---:|---:|---:|
| BTW | 16 | 5,000 | 20,000 | 3 |
| BTW | 32 | 10,240 | 20,000 | 3 |
| BTW | 64 | 40,960 | 20,000 | 3 |
| Random redistribution | 32 | 10,240 | 20,000 | 3 |
| BTW, doubled burn-in | 32 | 20,480 | 20,000 | 3 |
| Random redistribution, doubled burn-in | 32 | 20,480 | 20,000 | 3 |
| BTW, independent ensemble | 16 | 5,000 | One final observation | 20 |

There are 38 saved runs. The main experiments contain 240,000 grain additions after burn-in, of which 99,143 trigger an avalanche. The burn-in comparison adds another 120,000 recorded additions. Including all burn-in steps and ensemble runs gives 782,220 simulated steps.

Each ensemble observation comes from a separate run that starts with an empty grid. Its final height is taken after 5,001 additions. The 20 observations therefore come from independently driven systems.

### A2. Update rule and measurements

The grid is an L × L integer array. At each driving step, one site is chosen uniformly and receives one grain. A site with height at least 4 topples: its height falls by 4, and one grain is sent in each of the four nearest-neighbour directions. Grains sent outside the grid are lost. The next grain is added after every site has become stable. Edge and corner sites also have threshold 4. [C1]

I used a last-in, first-out queue to store sites that may need to topple. A site's height is checked again when it is removed from the queue. A neighbour is added when its height reaches 4, and the current site is added again if it remains unstable. This keeps the update in one short function.

For each grain addition, the program records the following quantities:

| Symbol | Meaning |
|---|---|
| s | Total number of topplings, including repeated topplings at the same site |
| a | Number of distinct sites that topple at least once |
| d | Number of grains lost through the boundary |
| r | Greatest Euclidean distance from the addition site to a site that topples |
| H | Mean grid height after the avalanche has finished |

With lattice spacing set to one and u(x) denoting the number of topplings at site x,

```text
s = sum_x u(x)
a = number of sites with u(x) > 0
r = max over toppled sites x of ||x - x_0||_2
H = sum_x h(x) / L^2
```

A step without a toppling has s = a = d = r = 0. An avalanche confined to the addition site also has r = 0, so I identify avalanches using s > 0. The length r measures spatial spread. Driving time counts grain additions; it does not count the individual topplings within an avalanche.

### A3. Checks on the implementation

| Check | Recorded outcome |
|---|---|
| Single toppling at the centre, edge, and corner, plus the handout example | All passed |
| All 256 stable 2 × 2 configurations, with a grain added at each of the four sites | 1,024 cases passed |
| Random unstable 8 × 8 configurations | 100 cases passed |
| LIFO, FIFO, and a separate synchronous array method | Same final heights, toppling counts, and loss in all 1,124 comparisons |
| Mass balance across all 782,220 saved steps | Maximum residual: 0 |
| Small-grid tests of random redistribution | 4,000 steps passed |
| Burning test on the saved deterministic final configurations | All 32 were recurrent |
| Matching the recorded driving sequences used in paired comparisons | All 9 comparisons matched |
| Clean-directory demo runs | All 4 trajectories matched the corresponding reference prefixes |

The local update is checked against the integer mass balance

```text
M_after = M_before + 1 - d.
```

The following bounds also apply after a complete relaxation:

```text
0 <= h(x) < 4
0 <= a <= min(s, L^2)
0 <= r <= sqrt(2) (L - 1).
```

The checks help catch implementation errors. The mathematical arguments for termination and uniqueness are given under Questions 11 and 12. The burning test establishes recurrence for the tested final configurations; it gives no measure of how thoroughly a trajectory has sampled the recurrent states.

### A4. Rechecking Figure 3 in the handout

Applying the stated toppling rule to the handout example gives:

```text
Initial grid       Final stable grid
1 3 3              2 1 1
2 4 2       ->     3 2 0
2 1 1              2 2 2
```

The centre, upper-middle, upper-right, and middle-right sites each topple once. Thus s = 4, a = 4, d = 4, and r = sqrt(2) when measured from the centre. The initial grid already contains 19 grains and is unstable. Relaxation leaves 15 grains, which agrees with the loss of 4.

The diagram in the handout misses a grain returning to the centre. I used the stated rule and the mass balance to check this case. Since no grain is added during this particular test, its balance is M_after = M_before − d. [C1]

## B. Main results

| Model | Mean height H | Avalanche probability | Mean s over all additions | 99th percentile of s, given s > 0 |
|---|---:|---:|---:|---:|
| BTW, L = 16 | 2.046474 ± 0.001910 | 40.982% ± 0.319 percentage points | 11.3331 ± 0.0491 | 192.66 ± 6.04 |
| BTW, L = 32 | 2.085122 ± 0.001067 | 41.883% ± 0.201 percentage points | 40.5030 ± 0.2150 | 942.57 ± 11.17 |
| BTW, L = 64 | 2.104019 ± 0.000124 | 43.175% ± 0.157 percentage points | 153.1406 ± 0.4993 | 4329.51 ± 153.25 |
| Random, L = 32 | 1.994755 ± 0.001094 | 39.198% ± 0.255 percentage points | 40.6439 ± 0.2192 | 1511.24 ± 40.53 |

Each entry is the mean of three run-level estimates, followed by their sample standard deviation. The percentiles are calculated separately for each run and then averaged. Their uncertainty reflects variation between these three runs.

Mean loss per grain addition is 0.999700, 0.999783, and 0.999833 for BTW at L = 16, 32, and 64. The random model gives 0.999667 at L = 32. These averages are close to the input of one grain per step, as expected when the total stored mass changes little over a long observation window.

The run-level values are in `results/summary.csv`; the averages and standard deviations are in `results/group_summary.csv`. Raw trajectories are in `results/data`.

## Question 1. How does scale invariance lead to a power law?

Suppose a nonzero function keeps its shape when its argument is rescaled. If this holds over a continuous range of scale factors, a homogeneous form is

```text
f(bx) = b^(-tau) f(x).
```

For a differentiable f, differentiating with respect to b and setting b = 1 gives

```text
x f'(x) = -tau f(x).
```

Separating variables and integrating gives

```text
f(x) = C x^(-tau).
```

The exponent controls the change in magnitude under rescaling. There is no characteristic x that changes the shape within the assumed range. By comparison, exp(−x/x_0) contains a characteristic scale x_0. Rescaling x changes its shape relative to that scale. [1]

This argument needs continuous scale invariance and enough regularity to differentiate. Invariance at only a discrete set of scale factors can allow additional log-periodic behaviour. The grid also introduces a minimum distance, while a finite system limits avalanche area and radius. The scaling argument therefore applies, at best, over an intermediate range of the measured distribution.

For a mass function p(s) approximately proportional to s^(−tau), the corresponding far-tail complementary cumulative distribution is approximately proportional to s^(1−tau), under the usual tail approximation with tau > 1. The exponent of the mass function and the slope of a CCDF plot must be kept separate.

## Question 2. Which features of BTW are relevant to self-organised criticality?

The model separates slow driving from fast relaxation. A grain is added only after the previous avalanche has finished. The threshold introduces a local nonlinear response: one extra grain can make a site topple and push its neighbours over the same threshold. Repeated local transfers can then spread the disturbance across the grid. Grains are conserved during interior transfers, while the open boundary provides an outlet. [1–3]

Starting from an empty grid, the measured height rises and then fluctuates within a much narrower range. Avalanche sizes cover a broad range, and larger grids allow larger events. These observations are consistent with the behaviour expected from the BTW model.

The evidence available here is finite: three grid widths, three runs per setting, and a fixed recording window. A height plateau alone gives little information about critical scaling. The distribution plots and the size comparison add useful evidence, although the fits below still show substantial dependence on the fitting range.

Relevant figures: `01_height.png` and `ccdf_sizes_0.png` through `ccdf_sizes_3.png`.

## Question 3. Why use an open boundary? What changes on an infinite grid?

On a finite closed grid, each driving step increases the total mass by one. A stable configuration can hold at most 3L² grains. Once the mass exceeds this value, complete stabilisation is impossible under a conservative toppling rule. The open boundary lets the finite system release grains. Every site in the square grid is connected to that boundary. [2,3]

An infinite grid needs a more careful specification. There is no uniform probability distribution giving every site of the countably infinite lattice the same positive selection probability. Driving can instead be restricted to a chosen finite set. With no global sink, the total mass then grows as grains are added, while grains can move further away from the driven region.

Transport out of a finite observation window changes the mass in that window. Those grains still belong to the infinite system. Questions about stabilisation and limiting distributions also depend on the initial configuration and the order in which limits are taken. A finite-mass initial state and an infinite-density initial state require different arguments. [3]

For this project, a finite open grid gives a well-defined driving distribution and a clear mass balance. The infinite-grid case is addressed through these conditions, without adding another large simulation.

## Question 4. How did the height prediction compare with the results?

My initial estimate used the four stable heights, 0, 1, 2, and 3. If they occurred equally often, their mean would be

```text
H_guess = (0 + 1 + 2 + 3) / 4 = 1.5.
```

This was a simple starting guess. It assumes uniform site-height frequencies and ignores the dependence produced by the dynamics.

The BTW simulations gave mean heights of 2.046474, 2.085122, and 2.104019 for L = 16, 32, and 64. All three are well above 1.5. The stationary dynamics favour a different set of height frequencies, so the equal-frequency assumption fails. The uniform measure on recurrent configurations also differs from independently choosing each site's height from the four stable values. [2,3]

For the infinite square-lattice BTW model, the stationary mean height is 17/8 = 2.125 under the 0–3 height convention. The reference using heights 1–4 gives 25/8; subtracting one converts that value to the convention used here. [4] The finite-grid averages move towards 2.125 as L increases, which is consistent with a smaller relative contribution from the boundary.

The height figure displays every 25th recorded step to keep the lines readable. All steps are retained when calculating the statistics.

## Question 5. What do steady state, stationarity, and equilibrium mean here?

A stable configuration has h(x) < 4 at every site. It stays unchanged until another grain is added. This is a statement about the threshold rule at one instant.

Statistical stationarity concerns the distribution over time. In a stationary regime, the relevant distributions and joint statistics are unchanged by a shift in observation time, even though individual configurations continue to change. For the saved simulations, I can check selected quantities such as window averages of H, avalanche frequency, and size percentiles. These checks give a practical assessment over the available observation window.

The phrase steady state needs its context. For a deterministic state equation it can mean a fixed state; for this driven random process, a nonequilibrium steady state refers to stable long-run statistics. The system keeps receiving grains and losing them at the boundary, so its sustained behaviour involves an ongoing flux. [1–3]

Summing the stepwise mass balance over N additions gives an exact identity:

```text
M_end - M_start = N - sum_t d_t
mean loss over all steps = 1 - (M_end - M_start) / N.
```

This identity holds for any finite window. In a long stationary window, the mass difference becomes small relative to N, giving mean loss close to one. Conditioning on s > 0 changes the denominator, so the conditional mean loss per avalanche has a different value.

The burn-in checks support a working stationary-window comparison, with some remaining sensitivity described in Section D.

## Question 6. How do time sampling and ensemble sampling compare?

Time sampling follows one trajectory. Successive observations can be correlated. Ensemble sampling observes separately driven systems under the same model settings. Their estimates can differ when the runs are short, the initial transient is still important, or the observable has substantial time correlation.

For a finite connected deterministic sandpile with an accessible sink and positive driving probability at every site, the addition-and-stabilisation chain has one recurrent communicating class. The stationary measure is uniform on recurrent configurations. Long-run time averages can be related to averages under that measure. [2,3]

I used the first BTW run at L = 16 for the time estimate. Its 20,000 post-burn-in heights were split into 40 non-overlapping blocks of 500 steps. The variation between block means gave an approximate standard error. For the ensemble estimate, 20 independent runs each supplied one height after 5,001 additions.

| Estimate | Mean H | Standard error | Approximate 95% interval |
|---|---:|---:|---:|
| One trajectory, 40 block means | 2.044285 | 0.001215 | [2.041828, 2.046741] |
| Twenty independent final observations | 2.055664 | 0.008105 | [2.038701, 2.072627] |

The intervals use Student t multipliers. The block means are treated as approximately independent for this diagnostic. Residual dependence would affect the time-series interval. The height autocorrelation values are saved in `height_acf.csv`.

The time estimate falls within the wider ensemble interval. This gives a reasonable consistency check for H at this sample size. It leaves uncertainty from finite sampling and burn-in, and it does not establish ergodicity for every observable.

Periodicity is another distinction worth keeping. For L = 1, the heights follow 1, 2, 3, 0 repeatedly; this sequence is included in the tests. The long-run time average exists, even though the distribution at each successive time from a fixed initial state cycles. Time-average convergence and convergence of the distribution at a fixed time are separate questions.

## Question 7. What do the four avalanche distributions look like?

### 7.1 Keeping track of zeros

The frequency tables include every grain addition. The percentages of zero values are:

| Model | s = 0 | a = 0 | d = 0 | r = 0 |
|---|---:|---:|---:|---:|
| BTW, L = 16 | 59.018% | 59.018% | 74.995% | 65.895% |
| BTW, L = 32 | 58.117% | 58.117% | 80.150% | 63.810% |
| BTW, L = 64 | 56.825% | 56.825% | 84.247% | 62.118% |
| Random, L = 32 | 60.802% | 60.802% | 84.793% | 65.622% |

Each percentage is averaged across three equally long runs, which gives the same percentage as pooling their records. The zero frequencies of s and a agree exactly. Radius also vanishes for an avalanche confined to its starting site. Loss is zero for avalanches that release no grains at the boundary.

Logarithmic plots use the positive part of the relevant variable. Each CCDF shows

```text
P(X >= x | X > 0).
```

Multiplying this curve by P(X > 0) gives the unconditional right-tail probability at positive x. The exact frequency files require no binning. For the density figures, I used logarithmic bins and divided by bin width; integer bin edges were rounded and deduplicated. Empty bins are omitted from the logarithmic display.

### 7.2 Patterns in the data

Toppling counts are strongly right-skewed: small avalanches are common and large ones occur much less often. Increasing L extends the range of large events. The 99th percentile of nonzero toppling counts rises from about 193 at L = 16 to about 4,330 at L = 64.

Area is also right-skewed and is bounded by L². It tends to increase with the number of topplings, although repeated topplings can raise s without visiting an additional site. Loss has a large mass at zero because many avalanches release no grains. Radius takes values allowed by lattice geometry and is bounded by sqrt(2)(L − 1).

A symmetric Gaussian gives a poor description of these positive distributions. The available plots show broad, right-skewed distributions with strong finite-size effects. Their finite ranges also limit what can be inferred about asymptotic tails.

### 7.3 Exploratory power-law fits

I fitted the integer toppling count above several chosen lower thresholds using a discrete power law with unbounded support:

```text
p(s | s >= s_min) = s^(-alpha) / zeta(alpha, s_min),  alpha > 1

Negative log-likelihood:
n log zeta(alpha, s_min) + alpha sum_i log(s_i).
```

A one-dimensional bounded optimiser estimates alpha. The output also contains the maximum distance between empirical and fitted CDFs, checking both sides of the discrete jumps. This KS distance is a fit diagnostic. [5]

| Lower threshold s_min | BTW, L = 16 | BTW, L = 32 | BTW, L = 64 | Random, L = 32 |
|---:|---:|---:|---:|---:|
| 5 | 1.5800 | 1.4141 | 1.3234 | 1.4528 |
| 10 | 1.7317 | 1.4862 | 1.3663 | 1.5120 |
| 20 | 1.9746 | 1.5819 | 1.4170 | 1.5833 |
| 50 | 2.6315 | 1.7705 | 1.5056 | 1.7010 |
| 100 | 3.9178 | 2.0070 | 1.5991 | 1.8390 |
| 200 | 5.8991 | 2.4372 | 1.7212 | 2.0328 |

These are the fitted alpha values. All 24 fits are saved in `exploratory_powerlaw.csv`, along with tail sample counts and KS distances. At s_min = 20, the four tail samples contain 8,776, 12,173, 14,345, and 9,390 observations, in the order shown above.

The fitted exponent increases noticeably as the threshold moves further into the tail. For BTW at L = 32, it changes from 1.4141 at a threshold of 5 to 2.4372 at 200. I would therefore avoid selecting one value as a precise critical exponent. The threshold sensitivity and finite-size curvature need to stay visible in the discussion.

No bootstrap goodness-of-fit p-value or likelihood-ratio comparison with a truncated power law or lognormal was calculated. The handout asks for fitting where possible; these fits provide an exploratory answer, together with their limitations. Known complications in simple BTW finite-size scaling also support caution when interpreting a single fitted slope. [5,6]

The outputs include eight CCDF figures, four density figures for the rule comparison, and sixteen exact frequency tables.

## Question 8. How are the four measurements related?

Before looking at the correlations, the rule suggests that an avalanche with more topplings will often reach more sites and travel further. Loss should be less closely related to size because it also depends on where the avalanche starts and whether it reaches the boundary.

I calculated Spearman rank correlations among all events with s > 0. Values with d = 0 or r = 0 remain in this sample. The table pools the three runs for each L = 32 model to describe their event distributions.

| Pair | BTW, L = 32 | Random, L = 32 |
|---|---:|---:|
| s and a | 0.999201 | 0.998611 |
| s and d | 0.553241 | 0.494851 |
| s and r | 0.983644 | 0.979802 |
| a and d | 0.552653 | 0.494227 |
| a and r | 0.986751 | 0.983518 |
| d and r | 0.540627 | 0.482679 |

Toppling count, area, and radius are very strongly positively related. Loss has a more scattered relationship with the other variables, consistent with the additional role of the boundary. A correlation close to one still permits a large numerical difference between s and a. Their definitions give a <= s, and repeated topplings can make that difference substantial.

Each scatter plot uses a fixed random sample of 2,500 nonzero avalanches. The correlations use every nonzero avalanche. The horizontal axis is log10(s); the vertical axes are log10(a + 1), log10(d + 1), and log10(r + 1). Adding one on the vertical axis allows zeros to remain visible. These are descriptive correlations; no independence-based significance test was used for the serially generated events.

## Question 9. What do the toppling-matrix conditions mean?

I follow the handout's sign convention: row x of Delta gives the change caused by toppling site x. Its diagonal entry is negative.

| Condition | Interpretation |
|---|---|
| Delta(x,y) = Delta(y,x) >= 0 for x != y | A toppling sends nonnegative amounts to other sites; symmetry describes undirected transfer |
| Delta(x,x) < 0 | The toppling removes grains from its own site; its threshold is −Delta(x,x) |
| Each row sums to at most zero | A toppling conserves mass or loses it |
| The sum of all entries is negative | At least one site can dissipate grains |

For a general finite graph, these conditions need an accessibility condition as well: each site must be connected to a dissipative site. The square open grid satisfies it. Symmetry is part of this undirected model; sandpiles can also be defined on directed dissipative graphs. [2,3]

The following small matrix shows why accessibility matters:

```text
Delta = [-1   1   0]
        [ 1  -1   0]
        [ 0   0  -1].
```

It satisfies the four listed conditions. However, sites 1 and 2 are disconnected from site 3, which is the only dissipative site. Starting from heights (1, 0, 0), the threshold-1 rule moves the grain repeatedly between sites 1 and 2. That component has no route to lose it.

## Question 10. Does the BTW matrix satisfy the conditions?

In two dimensions the nearest-neighbour rule has threshold 4. Its matrix is

```text
Delta(x,y) = -4  if x = y
Delta(x,y) =  1  if x and y are nearest neighbours within the grid
Delta(x,y) =  0  otherwise.
```

An interior site has four neighbours, giving row sum 0. A non-corner edge site has three, giving row sum −1. A corner has two, giving row sum −2. For L >= 2, the sum of all rows is −4L. When L = 1, the matrix is simply [−4], and all four grains leave at each toppling.

The threshold remains 4 at every site. With the negative diagonal convention, the instability condition is

```text
h(x) >= -Delta(x,x) = 4.
```

The printed condition h(x) >= Delta(x,x) in Equation (6) has a sign inconsistency: it would treat nonnegative stable heights as unstable when the diagonal is −4. The program uses the threshold implied by the stated toppling rule. [C1]

## Question 11. When can two topplings be exchanged?

Let Delta_x be row x of the toppling matrix, viewed as the increment vector for a toppling at x. For an executed toppling,

```text
T_x h = h + Delta_x.
```

If x and y are both unstable, toppling either one cannot reduce the other's height, since off-diagonal entries are nonnegative. Both orders are therefore legal, and

```text
T_y T_x h = h + Delta_x + Delta_y = T_x T_y h.
```

This gives the local exchange argument needed for two simultaneously legal topplings. [2,3]

There is a subtlety in a conditional operation that does nothing when its selected site is stable. Consider x at the upper-left and y at the upper-right:

```text
Initial heights:       [3 4]
                       [0 0]

Apply T_x, then T_y:   [4 0]
                       [0 1]

Apply T_y, then T_x:   [0 1]
                       [1 1]
```

In the first order, the operation at x initially does nothing. After y topples, x still needs to be processed. Once relaxation is completed, both routes reach the same stable configuration. This example shows why the legal-toppling condition matters when writing the operator argument.

The complete addition-and-stabilisation operators on stable configurations have the Abelian property. The termination and uniqueness argument below explains how local updates lead to that result.

## Question 12. Why does stabilisation end, and why is its result unique?

### 12.1 Termination on the finite open grid

Assume a finite connected grid, a finite nonnegative initial mass, and no extra grain additions during relaxation. Each legal BTW toppling leaves all heights nonnegative and can only conserve or decrease total mass.

Suppose a legal sequence contains infinitely many topplings. Since there are finitely many sites, some site must topple infinitely often. Every neighbour then receives infinitely many grains. If a neighbour toppled only finitely often, its height would grow without bound, contradicting the finite upper bound on total mass. Hence each neighbour must also topple infinitely often.

Repeating this argument along a path reaches a boundary site. That site would topple infinitely often and lose at least one grain on each toppling. Infinite loss contradicts the finite initial mass. Every legal relaxation must therefore terminate.

This argument uses the deterministic rule that sends a grain to each neighbour on every toppling. A pathwise statement for random redistribution needs its own treatment.

### 12.2 Uniqueness of the toppling counts

Take two legal, complete stabilisations of the same initial configuration h. Let their total toppling counts be u(x) and v(x).

Follow the first sequence and suppose that some site's count is about to exceed v for the first time. Just before that toppling at site x, the counts n satisfy

```text
n(x) = v(x), and n(y) <= v(y) for every y != x.
```

The height at x is then

```text
h(x) + Delta(x,x)n(x) + sum over y != x of Delta(y,x)n(y)

<= h(x) + Delta(x,x)v(x) + sum over y != x of Delta(y,x)v(y)

= the final height at x after the second stabilisation
< 4.
```

The inequality follows from the nonnegative off-diagonal entries. Site x is stable, so the proposed toppling is illegal. This contradicts the choice of the first excess toppling. Thus u <= v. Applying the same argument in the opposite direction gives v <= u, hence u = v. [2,3]

The final configuration is

```text
h_final = h + Delta^T u,
```

so it is unique as well. The result covers both the stable heights and the number of topplings at each site. The 1,124 numerical comparisons provide an additional check that the implementations follow this theory.

## C. Extension: random redistribution of four grains

### C1. Rule and paired comparison

The extension removes four grains from the toppling site, just as before. Each of those grains independently chooses one of the four directions with probability 1/4. Several grains can go to the same neighbour. A direction pointing outside the grid causes loss and is kept as drawn. The threshold remains 4. This is the random-redistribution option in the course handout. [C1]

I compared the rules at L = 32 using three runs per rule. Paired runs use identical post-burn-in addition positions. The burn-in positions, recorded addition positions, and redistribution directions use separate random streams. The direction stream continues through burn-in, so the doubled-burn-in runs pair the driving positions while allowing the internal random history to differ.

The plan expected possible changes in the distributions without assigning a direction to every change. The directions reported below come from the saved results.

### C2. Measured differences

| Quantity | BTW, L = 32 | Random redistribution, L = 32 |
|---|---:|---:|
| Mean height H | 2.085122 ± 0.001067 | 1.994755 ± 0.001094 |
| Avalanche probability, all additions | 0.418833 ± 0.002014 | 0.391983 ± 0.002554 |
| Probability of loss, all additions | 0.198500 ± 0.001429 | 0.152067 ± 0.000925 |
| Mean s, all additions | 40.502967 ± 0.214964 | 40.643933 ± 0.219226 |
| Mean s, given s > 0 | 96.705060 ± 0.530084 | 103.688425 ± 0.127480 |
| Mean a, given s > 0 | 78.293758 ± 0.623739 | 50.042343 ± 0.475324 |
| Mean r, given s > 0 | 7.365747 ± 0.037382 | 5.629499 ± 0.069437 |
| Mean loss, all additions | 0.999783 ± 0.000957 | 0.999667 ± 0.000388 |
| 95th percentile of s, given s > 0 | 472.666667 ± 7.234178 | 559.866667 ± 4.331666 |
| 99th percentile of s, given s > 0 | 942.570000 ± 11.173634 | 1511.240000 ± 40.531208 |

Entries are means and sample standard deviations across three runs. Probabilities here use the 0–1 scale.

At L = 32, the random rule lowers the mean height and reduces the avalanche probability by about 2.685 percentage points. Among additions that trigger an avalanche, the mean number of topplings rises from 96.705 to 103.688, an increase of about 7.22%. The mean area falls from 78.294 to 50.042, and the mean radius falls from 7.366 to 5.629. The 99th percentile of s rises by about 60.33%.

This combination suggests more repeated toppling within a smaller region. It is a plausible interpretation of the measurements; the simulation does not store every grain's path to test the mechanism separately. The ratio of mean s to mean a increases from about 1.235 to 2.072. That ratio describes two group means; calculating the mean of the event-by-event ratio s/a would answer a different question.

The CCDF curves cross in parts of their range. The random rule therefore gives larger values for the particular conditional means and high percentiles reported here, without ordering the entire distribution in the same way.

Loss events also become less common, while mean loss over all additions stays close to one. Fewer loss events can carry away more grains each. Keeping event probability, conditional event size, and the all-step mean separate makes these results easier to interpret.

### C3. A theoretical check on the all-step mean toppling count

Let A = −Delta and let v(x) be the expected number of topplings at site x per grain addition in a stationary regime. Uniform driving supplies 1/L² grains per site per step on average. Expected mass balance gives

```text
A v = (1/L^2) 1
E[s] = sum_x v(x).
```

For random redistribution, the expected number of grains sent in each direction is also one. Assuming stationarity and finite expected toppling counts gives the same balance equation. The result refers to all additions, including those with s = 0.

I solved the open-boundary discrete Laplacian using

```text
T = tridiag(-1, 2, -1)
A = I tensor T + T tensor I.
```

| Model | L | Theoretical mean s over all additions | Measured mean | Relative difference |
|---|---:|---:|---:|---:|
| BTW | 16 | 11.338215 | 11.333050 | −0.0456% |
| BTW | 32 | 40.580318 | 40.502967 | −0.1906% |
| Random | 32 | 40.580318 | 40.643933 | +0.1568% |
| BTW | 64 | 153.043100 | 153.140617 | +0.0637% |

The largest equation residual in the independent solve was below 2.4 × 10^(−16). The results are saved in `theory_mean_topples.csv`.

The measured all-step means lie within 0.2% of the theoretical values. The almost unchanged all-step mean at L = 32 is compatible with a higher conditional mean avalanche size: the random model also triggers avalanches less often.

### C4. What was checked about randomness and update order?

The LIFO/FIFO equality tests apply to the deterministic rule. With a single global random-direction stream, changing the update order assigns random instructions to different sites. Identical seeds then need not give identical realised paths.

Stochastic Abelian models can be studied by fixing a separate instruction sequence at each site. [2] The present extension is used for a statistical comparison of the two specified rules. It includes no separate proof of stochastic pathwise equivalence or of a universality class.

## D. Burn-in and sampling sensitivity

### D1. Checks used

For every run, the latter half of burn-in was split into three windows and the recorded phase into ten windows. I also compared the first and second 10,000-step halves of each main record. Both L = 32 rules were run again with doubled burn-in, using three paired driving sequences.

The files `blocks.csv`, `half_comparison.csv`, and `burn_sensitivity.csv` contain these comparisons. The original choice B = max(5,000, 10L²) was a starting setting. Its adequacy has to be assessed from the trajectories and sensitivity checks.

### D2. Effect of doubling burn-in

| Model | Quantity | 10,240 burn-in steps | 20,480 burn-in steps | Relative change |
|---|---|---:|---:|---:|
| BTW | Mean H | 2.085122 | 2.082551 | −0.123% |
| BTW | Avalanche probability | 0.418833 | 0.428083 | +2.209% |
| BTW | 99th percentile of s | 942.570000 | 903.490000 | −4.146% |
| Random | Mean H | 1.994755 | 1.993763 | −0.050% |
| Random | Avalanche probability | 0.391983 | 0.393000 | +0.259% |
| Random | 99th percentile of s | 1511.240000 | 1471.803333 | −2.610% |

Relative changes use the ratio of the new and original estimates. For example, the BTW avalanche probability rises by about 0.925 percentage points, corresponding to a relative increase of about 2.209%.

Average height changes little, while the 99th percentile changes by a few per cent. The main direction of the rule comparison remains the same at both burn-in lengths: the random model has lower average height, smaller mean avalanche area, and a higher 99th percentile of toppling count.

These checks leave some sampling uncertainty, especially in the tail. Three-run standard deviations capture between-run variation for this experiment. They cannot include every effect of mixing, residual dependence, and rare events. Changes after doubling burn-in can reflect both initial-state sensitivity and finite-window variation.

### D3. Scope of the conclusions

The results support a comparison of the chosen rules at L = 32 and a finite-size comparison of BTW over L = 16–64. The fitted exponents remain exploratory because they depend strongly on the chosen threshold. A larger study would need longer trajectories, more repeats, and explicit model-fit comparisons to examine critical scaling in detail.

The model represents a driven threshold system with simple redistribution rules. Its results should be interpreted at that level; quantitative predictions about real sand-grain mechanics would need additional physical assumptions.

## E. Files and their connection to the questions

### E1. Figure list

| File or group | Number | Use |
|---|---:|---|
| `01_height.png` | 1 | First-run height trajectories, including burn-in; Q2, Q4, Q5 |
| `ccdf_sizes_0.png` to `ccdf_sizes_3.png` | 4 | Positive-value CCDFs for the three BTW sizes; Q7 |
| `ccdf_rules_0.png` to `ccdf_rules_3.png` | 4 | Positive-value CCDFs for the two L = 32 rules; Q7 and extension |
| `density_rules_0.png` to `density_rules_3.png` | 4 | Log-binned positive densities at L = 32; Q7 and extension |
| `correlation_*.png` | 4 | Spearman matrices for the four main settings; Q8 |
| `scatter_BTW L=32_1.png` to `scatter_BTW L=32_3.png` | 3 | BTW s–a, s–d, and s–r plots; Q8 |
| `scatter_Random L=32_1.png` to `scatter_Random L=32_3.png` | 3 | Corresponding random-rule scatter plots; Q8 and extension |
| `grid.png` | 1 | Final stable grid from BTW L = 32, run 0 |
| `peak.png` | 1 | Site-level toppling counts for the largest recorded avalanche in that run |

For the distribution figures, suffixes 0, 1, 2, and 3 refer to s, a, d, and r. For scatter plots, suffixes 1, 2, and 3 refer to the vertical variables a, d, and r.

The event in `peak.png` was selected by its maximum s within BTW L = 32, run 0. It occurs at full-record index 23,885, or recorded grain addition 13,646 after burn-in. It has s = 2,145, a = 768, d = 29, and r approximately 27.0185. The largest site-level toppling count is 7. This selection illustrates a large event from one run; it is not a randomly chosen representative event.

### E2. Program structure

The main source has 300 physical lines, including comments and blank lines, and nine functions. It defines no classes.

| Function | Role | Questions |
|---|---|---|
| `relax` | Complete an avalanche, recording site-level topplings and loss | Q7, Q9–12, extension |
| `simulate` | Generate driving positions, run burn-in and sampling, check and save each step | Q4–8, extension |
| `check_model` | Local cases, exhaustive small cases, array-method comparison, random-rule checks | Q9–12 |
| `write_csv` | Save tables with named columns | Reproducibility |
| `describe` | Calculate conditional and all-step summaries | Q4–8 |
| `fit_tail` | Exploratory discrete likelihood fit and KS distance | Q7 |
| `finish` | Label and save one figure | Figures |
| `analyse` | Read saved runs, calculate statistics, and create figures | Q4–8, extension |
| `main` | Select the command and run the requested jobs | Whole workflow |

The English source changes only comments, docstrings, and error messages. The model rules, seeds, function structure, and calculations are preserved. The English-revision checks are recorded in `english_checks.json`; the earlier audit results are retained with their provenance.

The additional audit tables, such as the Laplacian calculation and the burning-test record, were produced separately from the main 300-line program. The README identifies the outputs rebuilt by `analyse` and the supplementary files supplied with the saved results.

## F. References and source notes

[C1] Lawrie, W., Kennedy, P., Ellis, J., and Sanderson, I. *Complex Systems: COMP90072 – The Art of Scientific Computing*. 17 August 2020. Supplied course handout, `COMP90072 - Complex - project.pdf`. The analysis follows its question numbering. Figure 3 and the threshold sign in Equation (6) were checked against the stated update rule.

[C2] Supplied Python skeleton and plotting example in `sandpile.tar.xz`. These were used to check the expected model behaviour. This package uses a separate function-based implementation.

[1] Bak, P., Tang, C., and Wiesenfeld, K. (1987). Self-organized criticality: An explanation of the 1/f noise. *Physical Review Letters*, 59, 381–384. DOI: 10.1103/PhysRevLett.59.381.

[2] Dhar, D. (1999). The Abelian sandpile and related models. *Physica A*, 263, 4–25. DOI: 10.1016/S0378-4371(98)00493-2. arXiv:cond-mat/9808047. Also see Dhar (1990), *Physical Review Letters*, 64, 1613–1616, DOI: 10.1103/PhysRevLett.64.1613, for the earlier formulation.

[3] Járai, A. A. *Sandpile models*. arXiv:1401.0354v3, revised 2018. Used for finite-graph stabilisation, the least-action argument, recurrent measures, and conditions relevant to infinite graphs.

[4] Poghosyan, V. S., Priezzhev, V. B., and Ruelle, P. (2011). Return probability for the loop-erased random walk and mean height in sandpile: a proof. *Journal of Statistical Mechanics*, P10004. DOI: 10.1088/1742-5468/2011/10/P10004. arXiv:1106.5453. The mean-height value is converted from the paper's 1–4 convention to the 0–3 convention used here.

[5] Clauset, A., Shalizi, C. R., and Newman, M. E. J. (2009). Power-law distributions in empirical data. *SIAM Review*, 51(4), 661–703. DOI: 10.1137/070710111. arXiv:0706.1062. The exploratory calculation uses the discrete likelihood formulation; bootstrap model checking and likelihood-ratio comparisons were outside the completed analysis.

[6] De Menech, M., Stella, A. L., and Tebaldi, C. (1998). Rare events and breakdown of simple scaling in the Abelian sandpile model. *Physical Review E*, 58, R2677–R2680. DOI: 10.1103/PhysRevE.58.R2677. arXiv:cond-mat/9805045.

**Acknowledgement for submission.** The code and these notes were developed with AI assistance. Any coursework submission should acknowledge that assistance and the source material in the form required by the course. The package includes no submission to the course site or repository.

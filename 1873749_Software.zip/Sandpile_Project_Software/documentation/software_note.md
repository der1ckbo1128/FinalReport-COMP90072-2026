# Project software
## Implementation and reproducibility note

COMP90072 — Two-dimensional sandpile dynamics  
Student name: Zhang Wenbo    Student ID: 1873749  
Submission date: 18 October 2026

### 1. What the program does

The program simulates the deterministic BTW rule and the selected four-grain random-redistribution extension. Both use an open square grid, threshold 4, a uniformly chosen addition site and complete relaxation before the next grain arrives. The only change in the extension is the direction of each outgoing grain. The numerical settings match the report outline, draft and final report.

The main file, `software/sandpile.py`, has 300 physical lines including comments and blank lines. It contains nine functions and no classes. A double-ended queue stores candidate sites. The program checks a site's height when it is removed, executes a legal toppling, and adds affected sites to the queue. It counts repeated topplings separately from the number of distinct sites visited.

| Function | Main responsibility |
|---|---|
| `relax` | Complete a relaxation and return site-level toppling counts and boundary loss |
| `simulate` | Generate the driving positions, run burn-in and recording, and save each step |
| `check_model` | Check local examples, all stable 2 × 2 grids and an independent array method |
| `write_csv` | Write a table with named columns |
| `describe` | Calculate all-addition and avalanche-conditional statistics |
| `fit_tail` | Estimate the discrete power-law exponent and record the KS distance |
| `finish` | Label and save a single figure |
| `analyse` | Read saved runs and rebuild core tables and figures |
| `main` | Read the command-line choice and start the requested task |

The per-addition record is `(s, a, d, r, H)`. Here s counts all topplings, a counts distinct toppled sites, d counts lost grains, r is the greatest Euclidean distance from the addition site to a toppled site, and H is the stable mean height. Zero-valued observations are retained. The event condition is s > 0.

Three independent streams are used for burn-in positions, recorded positions and, when needed, outgoing directions. Seeds 1000–1002 identify the main repeats; ensemble seeds are 2000–2019. The direction stream continues through burn-in. Paired experiments preserve the later addition positions, including when the burn-in length changes.

<!-- PAGEBREAK -->

### 2. Installation and commands

The reference runs used Python 3.13.5, NumPy 2.3.5, SciPy 1.17.0 and Matplotlib 3.10.8. These library versions are listed in `software/requirements.txt`. The optional report checks also use the versions in `requirements-report.txt`. A LaTeX installation is needed only to compile the report sources.

From the top level of the software archive:

```text
python -m pip install -r software/requirements.txt
python software/sandpile.py test --out checks
python software/sandpile.py demo --out demo_results
python software/sandpile.py full --out reproduced_results
python software/sandpile.py analyse --out software/results
```

`test` runs the model checks. `demo` uses one repeat of each main setting and 1,000 recorded additions, with the original burn-in settings. `full` runs all 38 experiments. A new output directory is required for simulation tasks, which prevents reference and new records from being mixed. `analyse` rebuilds the core tables and original 25 figures from the supplied arrays. It leaves the raw NPZ data unchanged. Python's `-O` option disables assertions and should be left off for these checks.

| Experiment | L | Burn-in per run | Recorded additions | Runs |
|---|---:|---:|---:|---:|
| BTW | 16 | 5,000 | 20,000 | 3 |
| BTW | 32 | 10,240 | 20,000 | 3 |
| BTW | 64 | 40,960 | 20,000 | 3 |
| Random redistribution | 32 | 10,240 | 20,000 | 3 |
| Doubled burn-in, each rule | 32 | 20,480 | 20,000 | 3 each |
| Independent BTW ensemble | 16 | 5,000 | 1 | 20 |

Each ensemble run supplies one endpoint after 5,001 additions. The main comparison contains 240,000 recorded additions, including 99,143 nonzero avalanches. There are 782,220 saved additions when burn-in and all supplementary runs are included.

The NPZ files contain the full trace, addition positions, final grid, the largest recorded event's toppling-count array, its index and JSON metadata. Twelve compressed CSV files provide readable post-burn-in copies of the main experiments. The README describes the array columns and where each output is stored.

<!-- PAGEBREAK -->

### 3. Verification and connection to the report

For every driven step, mass is checked using the exact integer identity `M_after = M_before + 1 - d`. The final grid must be nonnegative and below threshold. The area cannot exceed the total number of topplings. A direct relaxation test that adds no grain uses `M_after = M_before - d` instead.

The deterministic test set includes 1,024 additions to all stable 2 × 2 configurations and 100 random unstable 8 × 8 configurations. Last-in-first-out, first-in-first-out and the separate synchronous array method agree on the stable heights, site-level toppling counts and loss in all 1,124 comparisons. Small stochastic tests cover 4,000 additional steps. The saved 782,220-step record also satisfies the mass identity with zero residual.

The analysis keeps three statistical levels separate. A height trajectory and the selected avalanche map belong to specified runs. CCDFs and correlations pool equal-length main records. Reported means, quantiles and their sample standard deviations are calculated from three run-level estimates. Time–ensemble intervals use the separately stated block or endpoint calculation.

For the additional report checks and figure assets, run these commands from the archive root:

```text
python -m pip install -r requirements-report.txt
python verification/audit_report.py
python verification/make_report_figures.py
python verification/check_document.py
```

The audit recalculates the report's numerical summaries from the saved arrays. The plotting script creates the shared report figures. The document check targets the supplied final report and its number-to-location map. Draft-specific checks belonged to the earlier coursework stages archive and are outside this final software ZIP. The original full analysis and the shorter draft used the same data; their figure numbers are local to each document.

The report flowchart has editable LaTeX source in `report/flowchart.tex`. The compiled figure is supplied. `build_report.py` compiles the supplied final report after a LaTeX distribution with the required packages is installed. These reporting and auditing scripts are separate from the 300-line main program.

### 4. Limitations and source note

Fixed seeds and the recorded versions support reproduction. Runtimes vary by machine. The current local verification results are recorded in verification/current_submission_checks.json. The likelihood fits are exploratory: no formal bootstrap goodness-of-fit p-value or comparison against alternative distributions was calculated. Equality across processing orders was tested only for deterministic BTW.

The supplied course handout and Python skeleton were the model references. AI assistance was used for implementation, checking, analysis and writing. The final report includes the scholarly references; the software README identifies the original inputs and the reused data. Submission and any academic-integrity declaration remain the student's responsibility under the course rules.

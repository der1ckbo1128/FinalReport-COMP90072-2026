"""Build the LaTeX report from the supplied source and figure PDFs."""
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parent
latex = shutil.which("pdflatex")
bibtex = shutil.which("bibtex") or shutil.which("bibtex.original")
if latex is None or bibtex is None:
    raise SystemExit("Install a LaTeX distribution containing pdflatex and BibTeX first.")
commands = [[latex, "-no-shell-escape", "-interaction=nonstopmode", "-halt-on-error", "main.tex"],
            [bibtex, "main"],
            [latex, "-no-shell-escape", "-interaction=nonstopmode", "-halt-on-error", "main.tex"],
            [latex, "-no-shell-escape", "-interaction=nonstopmode", "-halt-on-error", "main.tex"]]
for command in commands:
    subprocess.run(command, cwd=root / "report", check=True)
shutil.copy2(root / "report/main.pdf", root / "1873749_Final_Report.pdf")
print("Built 1873749_Final_Report.pdf")

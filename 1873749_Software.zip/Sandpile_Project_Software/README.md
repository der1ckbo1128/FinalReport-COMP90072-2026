# COMP90072 Sandpile project software

Zhang Wenbo | Student ID 1873749 | 18 October 2026

This ZIP is the Project software submission. The separate Final report submission
is `1873749_Final_Report.pdf`; an identical PDF and its LaTeX source are also
included here. See `documentation/software_note.md` for the implementation note.

## Install and run

Extract the ZIP and open a terminal in the `Sandpile_Project_Software` folder.
Use a new virtual environment. The reference environment is Python 3.13.5,
NumPy 2.3.5, SciPy 1.17.0 and Matplotlib 3.10.8; dependency versions are pinned.

```text
python -m venv .venv
```

Activate with `.venv\Scripts\Activate.ps1` in PowerShell,
`.venv\Scripts\activate.bat` in Command Prompt, or
`source .venv/bin/activate` on macOS/Linux. Then run:

```text
python -m pip install -r software/requirements.txt
python software/sandpile.py test --out checks
python software/sandpile.py demo --out demo_results
python software/sandpile.py full --out reproduced_results
python software/sandpile.py analyse --out software/results
```

`test` runs the deterministic and stochastic checks. `demo` runs four main
settings with 1,000 recorded additions each. `full` regenerates all 38 runs.
Use a new output directory for simulations: existing NPZ files cause the program
to stop to prevent mixing records. `analyse` reads the supplied records and
rebuilds summaries and original figures; it does not change the raw NPZ files.
Do not use Python's `-O` flag, which disables test assertions.

## Included files

| Path | Contents |
|---|---|
| `software/sandpile.py` | Main simulation and analysis program, 300 lines, nine functions |
| `software/requirements.txt` | Pinned simulation dependencies |
| `software/README.md` | Definitions of variables, NPZ fields and random seeds |
| `software/results/data/` | All 38 reference NPZ files and 12 compressed readable CSV files |
| `software/results/` | Summary tables, distribution frequencies, correlations and original figures |
| `documentation/software_note.md` | Implementation, commands, validation and limitations |
| `documentation/analysis_notes.md` | Detailed calculations and answers to the project questions |
| `verification/` | Audit/figure scripts, data hashes, numerical maps and checks |
| `report/` | Final report LaTeX, bibliography, 14 figure assets and compiled PDF |
| `1873749_Final_Report.pdf` | Copy of the PDF submitted under Final report |
| `build_report.py` | Optional PDF rebuild script |
| `requirements-report.txt` | Additional report audit dependencies |
| `MANIFEST.sha256` | SHA-256 of every other delivered file |

## Report calculations and compilation

```text
python -m pip install -r requirements-report.txt
python verification/audit_report.py
python verification/make_report_figures.py
python build_report.py
python verification/check_document.py
```

LaTeX (pdfLaTeX and BibTeX) is required only for `build_report.py`; it is not
needed for the simulation. The numerical audit recomputes the report summaries
and transport calculation from the saved reference arrays. The document check
uses `report/main.pdf`. The report PDF is supplied for reading without compiling.
The LaTeX source is the editable final report. Earlier Word copies were excluded
because they were not synchronized with this LaTeX final report.

## Verification and limits

The reference records contain 782,220 steps, including burn-in and supplementary
runs; the main experiments contain 240,000 post-burn-in additions and 99,143
nonzero avalanches. Current checks are documented in
`verification/current_submission_checks.json`. Earlier verification records are
retained as historical records; `MANIFEST.sha256` describes this delivered ZIP.

Means and quantiles are calculated within each run and then summarized over
three runs. CCDFs and correlations pool the stated event samples. Fitted
power-law exponents remain exploratory; no formal bootstrap fit p-value or
alternative-distribution likelihood-ratio comparison is claimed.

## Sources and assistance

The course handout and Python skeleton were the model references. Scholarly
references are in `report/references.bib`. AI assistance was used in developing
and checking the implementation, organizing the analysis, and drafting/editing
the report. The report contains the corresponding acknowledgement.
